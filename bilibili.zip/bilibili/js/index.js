    // 1. 初始数据
    const data = [
        { url: './images/slider01.jpg', title: '对人类来说会不会太超前了？', color: 'rgb(100, 67, 68)' },
        { url: './images/slider02.jpg', title: '开启剑与雪的黑暗传说！', color: '#1f2d36' },
        { url: './images/slider03.jpg', title: '真正的jo厨出现了！', color: 'rgb(36, 31, 33)' },
        { url: './images/slider04.jpg', title: '李玉刚：让世界通过B站看到东方大国文化', color: 'rgb(139, 98, 66)' },
        { url: './images/slider05.jpg', title: '快来分享你的寒假日常吧~', color: 'rgb(67, 90, 92)' },
        { url: './images/slider06.jpg ', title: '哔哩哔哩小年YEAH', color: 'rgb(166, 131, 143)' },
        { url: './images/slider07.jpg', title: '一站式解决你的电脑配置问题！！！', color: 'rgb(53, 29, 25)' },
        { url: './images/slider08.jpg', title: '谁不想和小猫咪贴贴呢！', color: 'rgb(99, 72, 114)' },
        ]
        // 获取元素
        const img = document.querySelector('.slider-wrapper img')
        const p = document.querySelector('.slider-footer p')
        const footer = document.querySelector('.slider-footer')
        // 右侧按钮业务
        // 1.1获取右侧按钮
        const next = document.querySelector('.next')
        let i = 0 //信号量 控制播放图片张数
        // 1.2注册点击事件
        next.addEventListener('click', function () {
            i++
            // 1.6如果大于8复原为0
            if (i >= data.length) {
                i = 0
            }
            // 得到对应对象
            console.log(data[i]);
            // 渲染对应数据
            toggle()
        })
        // 左侧按钮业务
        // 获取左侧按钮
        const prev = document.querySelector('.prev')
        prev.addEventListener('click', function () {
            i--
            // 1.6如果小于0复原为7
            if (i < 0) {
                i = data.length - 1
            }
            // 得到对应对象
            console.log(data[i]);
            // 渲染对应数据
            toggle()
        })
        // 声明一个渲染函数作为复用
        function toggle() {
            img.src = data[i].url
            p.innerHTML = data[i].title
            footer.style.backgroundColor = data[i].color
            // 更换小圆点 
            // 移除原先小圆点
            document.querySelector('.slider-indicator .active').classList.remove('active')
            document.querySelector(`.slider-indicator li:nth-child(${i+ 1})`).classList.add('active')
        }
        // 自动播放模块
        let timeid =  setInterval(function () {
            // 利用js自动调用点击事件
            // 实际是在调用函数
            next.click()
        },3000)
        // 鼠标经过停止定时器
        // 4.1获取事件
        const slider = document.querySelector('.slider')
        slider.addEventListener('mouseenter',function () {
            // 停止定时器
            clearInterval(timeid)
        })
        slider.addEventListener('mouseleave',function () {

            // 停止定时器
            clearInterval(timeid)
            timeid =  setInterval(function () {
            // 利用js自动调用点击事件
            // 实际是在调用函数
            next.click()
            },3000)
        })
        const data_w = [
            { url: './images/quanyou.avif'},
            { url: './images/quanyou.avif'},
            { url: './images/quanyou.avif'},
            { url: './images/quanyou.avif'},
            {},]
        // 获取元素
        const imG = document.querySelector('.feed-card-1 .pictures img')
        // 利用map方法遍历数组，返回对应url地址
        function render () {
        }
        // 获取电梯元素
        const elevator = document.querySelector('.elevator')
        // 当页面滚动大于500px，就显示电梯导航
        // 给页面添加滚动事件
        window.addEventListener('scroll', function(){
            // 当被卷去的头部大于500px 就显示电梯
            const n = this.document.documentElement.scrollTop
            if (n >= 200) {
                elevator.style.opacity = 1
            } else {
                elevator.style.opacity = 0
            }

        })
        // 点击返回页面顶部
        elevator.addEventListener('click', function(){
            document.documentElement.scrollTop = 0
        })
        const shortcut_copy = document.querySelector('.shortcut_copy')
        // 当页面滚动大于500px，就显示电梯导航
        // 给页面添加滚动事件
        window.addEventListener('scroll', function(){
            // 当被卷去的头部大于500px 就显示电梯
            const n = this.document.documentElement.scrollTop
            if (n >= 91) {
                shortcut_copy.style.opacity = 1
            } else {
                shortcut_copy.style.opacity = 0
            }
        })
        const a = document.querySelector('.new-w .feed-card-1 .text a')
        a.addEventListener('click' , function() {
            console.log(1);
        })